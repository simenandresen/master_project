
[kest, L,P]=kalman(sys_tot,0.09*eye(6),0.25*eye(6),0)
