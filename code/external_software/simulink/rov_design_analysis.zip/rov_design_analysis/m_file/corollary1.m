% time response of linear body velocity ROV RRC 1/2
figure(3)
plot(tout, g,tout,gr,tout,0);
xlabel('Time(sec)')
legend('left term','right term',0);

