G_tot=G46_rov*G44_thruster;
figure(4)
run gerdisk_rov











