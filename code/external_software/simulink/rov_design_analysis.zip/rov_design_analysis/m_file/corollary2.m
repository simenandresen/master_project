% time response of linear body velocity ROV RRC 1/2
figure(4)
plot(tout, r,tout,0);
xlabel('Time(sec)')
ylabel('r(rad/s)')

