% observer gain L
K = acker(At,Bt,[-1 -1 -1 -1 -1 -1]) 
 
