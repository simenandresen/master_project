Follow the steps below to setup the package:
 
 1> unzipped the rov_design_analysis.zip into
 C:\Matlab7\toolbox\rov_design_analysis
 
 2> in Matlab7, click "file" menu and click "set
 Path".Select "Add with subfolder" then browse for   
    C:\Matlab7\toolbox\rov_design_analysis.

 3> open SIMULINK. Scroll down and select the toolbox
 "rov_design_analysis" and do a right-click.
 
 4> start using the RDA by dragging the desired block
 to a new *.mdl file.
