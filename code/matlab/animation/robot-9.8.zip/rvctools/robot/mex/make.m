mex CFLAGS=-std=c99 frne.c ne.c vmath.c
